/* This is a C program written for ESD lab 3.  The 
 program assumes a nios_system with a periodic interrupt timer
 and an 8-bit output PIO named leds. */


/* alt_types.h and sys/alt_irq.h need to be included for the interrupt
  functions
  system.h is necessary for the system constants
  io.h has read and write functions */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
//#include "altera_avalon_timer_regs.h"
//#include "altera_avalon_timer.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

//define addresses and constants for important values
#define hex0      0x11040
#define hex1      0x11030
#define hex2      0x11020
#define hex4      0x11010
#define hex5      0x11000
#define zero      0x40
#define one    	  0x79
#define two       0x24
#define three     0x30
#define four      0x19
#define five      0x12
#define six       0x02
#define seven     0x78
#define eight     0x00
#define nine      0x10

#define switches  0x11060    	//find the base address of Switches in the system.h file
#define keys      0x11050   	//find the base address of keys in the system.h file
#define servo	  0x0

#define min_angle 0x0000C350     // 45 degrees
#define max_angle 0x000186A0     // 135 degrees

//set up pointers to peripherals
uint32* hex_disp_0 = (uint32*)hex0;
uint32* hex_disp_1 = (uint32*)hex1;
uint32* hex_disp_2 = (uint32*)hex2;
uint32* hex_disp_4 = (uint32*)hex4;
uint32* hex_disp_5 = (uint32*)hex5;
uint32* keys_val = (uint32*)keys;
uint32* switches_val = (uint32*)switches;
uint32* servo_ctrl = (uint32*)servo;



//angle value to hex displays
void decode_max(int angle_val) {
	int remainder;

	switch(angle_val/100) {

	   case 1  :
		  *hex_disp_2 = one;
	      break;

	   case 2  :
		  *hex_disp_2 = two;
	      break;

	   case 3  :
		  *hex_disp_2 = three;
	      break;

	   case 4  :
		  *hex_disp_2 = four;
	      break;

	   case 5  :
		  *hex_disp_2 = five;
	      break;

	   case 6  :
		  *hex_disp_2 = six;
	      break;

	   case 7  :
		  *hex_disp_2 = seven;
	      break;

	   case 8  :
		  *hex_disp_2 = eight;
	      break;

	   case 9  :
		  *hex_disp_2 = nine;
	      break;

	   case 0  :
		  *hex_disp_2 = zero;
	      break;

	   default :
		   *hex_disp_2 = zero;
	}
	remainder = angle_val%100;
  	switch(remainder/10) {

	   case 1  :
		  *hex_disp_1 = one;
	      break;  
                
	   case 2  :  
		  *hex_disp_1 = two;
	      break;  
                
	   case 3  :  
		  *hex_disp_1 = three;
	      break;  
                
	   case 4  :  
		  *hex_disp_1 = four;
	      break;  
                
	   case 5  :  
		  *hex_disp_1 = five;
	      break;  
                
	   case 6  :  
		  *hex_disp_1 = six;
	      break;  
                
	   case 7  :  
		  *hex_disp_1 = seven;
	      break;  
                
	   case 8  :  
		  *hex_disp_1 = eight;
	      break;  
                
	   case 9  :  
		  *hex_disp_1 = nine;
	      break;  
                
	   case 0  :  
		  *hex_disp_1 = zero;
	      break;

	   default :
		   *hex_disp_1 = zero;
	}
  
   	switch(remainder%10) {

	   case 1  :
		  *hex_disp_0 = one;
	      break;  
                
	   case 2  :  
		  *hex_disp_0 = two;
	      break;  
                
	   case 3  :  
		  *hex_disp_0 = three;
	      break;  
                
	   case 4  :  
		  *hex_disp_0 = four;
	      break;  
                
	   case 5  :  
		  *hex_disp_0 = five;
	      break;  
                
	   case 6  :  
		  *hex_disp_0 = six;
	      break;  
                
	   case 7  :  
		  *hex_disp_0 = seven;
	      break;  
                
	   case 8  :  
		  *hex_disp_0 = eight;
	      break;  
                
	   case 9  :  
		  *hex_disp_0 = nine;
	      break;  
                
	   case 0  :  
		  *hex_disp_0 = zero;
	      break;

	   default :
		   *hex_disp_0 = zero;
	}
  return;
}

//angle value to hex displays
void decode_min(int angle_val) {
	int remainder;
	remainder = angle_val%100;
    	switch(remainder/10) {

	   case 1  :
		  *hex_disp_5 = one;
	      break;  
                
	   case 2  :  
		  *hex_disp_5 = two;
	      break;  
                
	   case 3  :  
		  *hex_disp_5 = three;
	      break;  
                
	   case 4  :  
		  *hex_disp_5 = four;
	      break;  
                
	   case 5  :  
		  *hex_disp_5 = five;
	      break;  
                
	   case 6  :  
		  *hex_disp_5 = six;
	      break;  
                
	   case 7  :  
		  *hex_disp_5 = seven;
	      break;  
                
	   case 8  :  
		  *hex_disp_5 = eight;
	      break;  
                
	   case 9  :  
		  *hex_disp_5 = nine;
	      break;  
                
	   case 0  :  
		  *hex_disp_5 = zero;
	      break;

	   default :
		   *hex_disp_5 = zero;
	}
  
   	switch(remainder%10) {

	   case 1  :
		  *hex_disp_4 = one;
	      break;  
                
	   case 2  :  
		  *hex_disp_4 = two;
	      break;  
                
	   case 3  :  
		  *hex_disp_4 = three;
	      break;  
                
	   case 4  :  
		  *hex_disp_4 = four;
	      break;  
                
	   case 5  :  
		  *hex_disp_4 = five;
	      break;  
                
	   case 6  :  
		  *hex_disp_4 = six;
	      break;  
                
	   case 7  :  
		  *hex_disp_4 = seven;
	      break;  
                
	   case 8  :  
		  *hex_disp_4 = eight;
	      break;  
                
	   case 9  :  
		  *hex_disp_4 = nine;
	      break;  
                
	   case 0  :  
		  *hex_disp_4 = zero;
	      break;

	   default :
		   *hex_disp_4 = zero;
	}	
  return;
}
int min_barrier(){
	decode_min(*switches_val);
	//convert switch value to clock counts
	int counts = (*switches_val)*555.5+25000;
  	//push clock counts to max barrier
	*(servo_ctrl + 0) = counts;		
	return counts;
}

int max_barrier(){
	decode_max(*switches_val);
	//convert switch value to clock counts
	int counts = (*switches_val)*555.5+25000;
  	//push clock counts to max barrier
	*(servo_ctrl + 1) = counts;	
	return counts;
}

void keys_isr(void *context){
	if ((*keys_val & 0x04) == 0){
	decode_min(*switches_val);
	}
	if ((*keys_val & 0x02) == 0){
	decode_max(*switches_val);
	}   	   
    return;
}

void servo_isr(void *context){
	int min_angle_val;
	int max_angle_val;
	if ((*keys_val & 0x04) == 0){
		min_angle_val = min_barrier(); 
	}
	else if ((*keys_val & 0x02) == 0){
		max_angle_val = max_barrier();
	}
	else {
		*(servo_ctrl + 0) = min_angle_val;	
		*(servo_ctrl + 1) = max_angle_val;	
	}
    return;
}

//Have servo sweep at different angles
//write enable
//write address min angle/max angle
//write angle value
//write disable
// let run until write enabled by state machine

int main(void)
{
	// interrupt on keys
	// use a mask
	//keys register enable a interrupt
	*(keys_val + 2) = 1;
	// if it looks weird at the start dont worry just treat it like a break point and hit key 3 to continue
	// if the reset button is hit put zeros on the hex displays
   // initialize displays to zero
	*hex_disp_0 = 0x40;
	*hex_disp_1 = 0x40;
	*hex_disp_2 = 0x40;
	*hex_disp_4 = 0x40;
	*hex_disp_5 = 0x40;	
  
	//initial set of angle to 45
	decode_min(45);
	*(servo_ctrl + 0) = 0x0000C350;
	//initial set of angle to 135
	decode_max(135);
	*(servo_ctrl + 1) = 0x000186A0;
   // servo crtl ptr + address offset = write data
	alt_ic_isr_register(KEYS_IRQ_INTERRUPT_CONTROLLER_ID,KEYS_IRQ,keys_isr,0,0);
	alt_ic_isr_register(SERVO_CONTROLLER_0_IRQ_INTERRUPT_CONTROLLER_ID,SERVO_CONTROLLER_0_IRQ,servo_isr,0,0);

  return 0;
}
