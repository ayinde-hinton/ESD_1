/* This is a C program written for ESD lab 6.  The 
 program assumes a nios_system with a periodic interrupt timer
 and an 8-bit output PIO named leds. */


/* alt_types.h and sys/alt_irq.h need to be included for the interrupt
  functions
  system.h is necessary for the system constants
  io.h has read and write functions */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

//define addresses and constants for important values
#define zero      0x40
#define one    	  0x79
#define two       0x24
#define three     0x30
#define four      0x19
#define five      0x12
#define six       0x02
#define seven     0x78
#define eight     0x00
#define nine      0x10

#define leds      0x9010    	//find the base address of Switches in the system.h file
#define keys      0x9000  	//find the base address of keys in the system.h file
#define ram		  0x0

volatile uint32* keys_val = (uint32*)keys;
uint32* leds_val = (uint32*)leds;

uint32* ram_addr = (uint32*)ram;
uint16* ram_addr_16 = (uint16*)ram;
uint8* ram_addr_8 = (uint8*)ram;


void byte_access(uint32 start_addr, uint32 bytes_to_test, uint8 test_data) {
    for (int i = start_addr; i <= bytes_to_test; i++) {
    	*(ram_addr_8 + i) = test_data;
    }

// loop two: read requested location to confirm successful write
    for (int i = start_addr; i <= bytes_to_test; i++) {
		if (*(ram_addr_8 + i) != test_data){
			*leds_val = 0xFF; // turn all leds on
			printf("Error \n");
			printf("Address: %x \n", i);
			printf("Read: %x \n", *(ram_addr_8 + i));
			printf("Expected: %x \n", test_data);
			// test failed
		} else {
			*leds_val = 0x00; // turn all leds on

		}
    }
}

void half_word_access(uint32 start_addr, uint32 bytes_to_test, uint16 test_data) {
	    for (int i = start_addr; i <= bytes_to_test/2; i++) {
	    	*(ram_addr_16 + i) = test_data;
	    }

	    for (int i = start_addr; i <= bytes_to_test/2; i++) {
	    		if (*(ram_addr_16 + i) != test_data){
	    			*leds_val = 0xFF; // turn all leds on
	    			printf("Error \n");
	    			printf("Address: %x \n", i*2);
	    			printf("Read: %x \n", *(ram_addr_16 + i));
	    			printf("Expected: %x \n", test_data);
	    			// test failed
	    		} else {
	    			*leds_val = 0x00; // turn all leds on
	    		}

	    }
}
//16k bytes means w use 16384 as bytes to test for byte access
//to multiply the amount of bytes we test by two we divide number of bytes to be tested by two
//to multiply the amount of bytes we test by four we divide number of bytes to be tested by four
void full_word_access(uint32 start_addr, uint32 bytes_to_test, uint32 test_data) {
	    for (int i = start_addr; i <= bytes_to_test/4; i++) {
	    	*(ram_addr + i) = test_data;
	    }

	    for (int i = start_addr; i <= bytes_to_test/4; i++) {
	    	//for (int j = 0; j < bytes_to_test; j++){
	    		if (*(ram_addr + i) != test_data){
	    			*leds_val = 0xFF; // turn all leds on
	    			printf("Error \n");
	    			printf("Address: %x \n", i*4);
	    			printf("Read: %x \n", *(ram_addr + i));
	    			printf("Expected: %x \n", test_data);
	    			// test failed
	    		} else {
	    			*leds_val = 0x00; // turn all leds on
	    		}
	    }
}

void keys_isr(void *context){
	// try invrting the keys_val mask
	//if((*keys_val & 0x02) == 1){
		*leds_val = 0x18; // turn all leds on
		printf("RAM Test Done \n"); // how to send this to JTAG?
		while(1){}
	//}
	*(keys_val + 3) = 0x01;
	return;
}

int main(void) {
	*leds_val = 0x00; // turn all leds off
	*(keys_val + 3) = 0x01; //to clear any residuals
	//keys register enable a interrupt
	*(keys_val + 2) = 0x01;
//isr set up can't go here cause it sends us straight into the isr
alt_ic_isr_register(KEY_IRQ_INTERRUPT_CONTROLLER_ID,KEY_IRQ,keys_isr,0,0);
	while(1){ // this goes in every main loop
		//Ram Test
		full_word_access(0x00000000,16383,0x12345678); // 32bit test
		half_word_access(0x00000000,16383,0x1234); // 16bit test
		byte_access(0x00000000,16383,0x12); // 8bit test
	}

// in debug if system time stamp mismatch; likely a difference in the nios systems attempting to be implemented so check what's being compiled
  return 0;
}
