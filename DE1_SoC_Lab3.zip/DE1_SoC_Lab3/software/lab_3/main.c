/* This is a C program written for ESD lab 3.  The 
 program assumes a nios_system with a periodic interrupt timer
 and an 8-bit output PIO named leds. */


/* alt_types.h and sys/alt_irq.h need to be included for the interrupt
  functions
  system.h is necessary for the system constants
  io.h has read and write functions */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
#include "altera_avalon_timer_regs.h"
#include "altera_avalon_timer.h"

// create standard embedded type definitions
typedef   signed char   sint8;              // signed 8 bit values
typedef unsigned char   uint8;              // unsigned 8 bit values
typedef   signed short  sint16;             // signed 16 bit values
typedef unsigned short  uint16;             // unsigned 16 bit values
typedef   signed long   sint32;             // signed 32 bit values
typedef unsigned long   uint32;             // unsigned 32 bit values
typedef         float   real32;             // 32 bit real values

//define addresses and constants for important values
#define switches  0x11050    //find the base address of Switches in the system.h file
#define keys      0x11040    //find the base address of keys in the system.h file
#define leds	  0x11030
#define hex0      0x11020
#define zero      0x40
#define one    	  0x79
#define two       0x24
#define three     0x30
#define four      0x19
#define five      0x12
#define six       0x02
#define seven     0x78
#define eight     0x00
#define nine      0x10

uint8 array[] = {zero, one, two, three, four, five, six, seven, eight, nine};
volatile uint8 i = 0;
//set up pointers to peripherals
uint32* hex_disp = (uint32*)hex0;
uint32* keys_val = (uint32*)keys;
uint32* switches_val = (uint32*)switches;
uint32* leds_val = (uint32*)leds;
uint32* TimerPtr = (uint32*)TIMER_0_BASE;

void increment(void)
{
	//check if the pointer would put us past the array, if not increment
	if(i < 9) {
		i = i + 1;
	}
    return;
}

void decrement(void)
{
	//check if the pointer would put us past the array, if not decrement
	if(i > 0) {
		i = i - 1;
	}
    return;
}

void keys_isr(void *context)
{
	//read switch and determine what to do to array pointer
	  if ((*switches_val & 0x01) == 0) {
		decrement();
	  } else {
		increment();
	  };
	  //reset interrupt flag
	  //better to invert or set to 0x00, Depends on the hardware and how it's set up to reset things
	  //clears interrupt
	  *(keys_val + 3) = 0x02;
    return;
}


void timer_isr(void *context)
{
	*leds_val = ~*leds_val;
	// clear interrupt
	*TimerPtr = 0;
    return;
}


int main(void)
{
	//keys register enable a interrupt
	//keys_val +2 gets me to the register offset,
	//the port lines up with the I/O labeling; so an interrupt on key 1 is on port 1 or the keys register
	*(keys_val + 2) = 0x02;
	//have program loop until key 4 pressed
	while(*keys_val & 0x08){
		// display zero/current value to hex display
		*hex_disp = array[i];
		//check if key pressed (polling)
		// while pointer to keys address bit masked with 0x02 is not equal to one stay in the while loop
		while ((*keys_val & 0x02)) {
			//poll for key press
		};
		// while pointer to keys address bit masked with 0x02 is equal to one stay in the while loop and determine whether or not to increment or decrement
		while ((*keys_val & 0x02) == 0) {
			//poll for key release
		};
		// trigger isr upon key release
		// alt_ic_isr_register sets up the isr in the NIOS
		alt_ic_isr_register(KEYS_IRQ_INTERRUPT_CONTROLLER_ID,KEYS_IRQ,keys_isr,0,0);
		alt_ic_isr_register(TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID,TIMER_0_IRQ,timer_isr,0,0);
	};
    return 0;
}
